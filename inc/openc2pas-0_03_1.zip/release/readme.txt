OpenC2Pas Version 0.03
changelog.txt in src\docs

Open source C/C++/BCB to Object Pascal (Delphi/Kylix) translator.

The purpose of this software is to save time in converting C/C++ source code
to Object Pascal code: it is meant as a time saver, don't expect complete
translations.

Project Full Name:  OpenC2Pas
Project Unix Name:  c2pas
CVS Server:         cvs.c2pas.sourceforge.net
Shell/Web Server:   c2pas.sourceforge.net
__________________________________________________

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
